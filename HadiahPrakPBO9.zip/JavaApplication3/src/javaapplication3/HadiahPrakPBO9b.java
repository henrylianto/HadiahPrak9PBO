/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication3;

/**
 *
 * @author Henry Lianto
 */
import javax.swing.*;
import java.awt.event.*;

public abstract class HadiahPrakPBO9b implements ActionListener{

    /**
     * @param args the command line arguments
     */
    private static void createAndShowGUI(){
        JFrame frame = new JFrame("Program menambah");
        //buat frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(20, 30, 300, 150);
        frame.getContentPane().setLayout(null);
        
        //Buat tombol
        JButton butt= new JButton("Klik Disini");
        frame.getContentPane().add(butt);
        butt.setBounds(20, 30, 200, 20);
        
        
        
        //membuat instance objek aplikasi   
        HadiahPrakPBO9b app = new HadiahPrakPBO9b() {};
            //make the label
         app.label = new JLabel("clicks = 0");
         app.label.setBounds(20, 50, 200,30);
         frame.getContentPane().add(app.label);
         
         butt.addActionListener(app);
         frame.setVisible(true);          
            
    }
            public void actionPerformed(ActionEvent e) {
             
             clickCount++;
             label.setText("clicks = "+clickCount);  
            }
       
       
        
        
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(new Runnable (){
                public void run(){
                    createAndShowGUI();
                }
        });
    }
    int clickCount=0;
    JLabel label;
}
